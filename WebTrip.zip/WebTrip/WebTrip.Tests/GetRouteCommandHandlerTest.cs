﻿using Xunit;
using FluentAssertions;
using WebTrip.Tests.Fixture;
using WebTrip.Domain.Entity;
using WebTrip.Application.Interfaces;
using Moq;
using WebTrip.Application.Commands.GetRouteBetterCost;
using WebTrip.Tests.Utils;
using Microsoft.AspNetCore.Http;
using WebTrip.Application.Models;


namespace WebTrip.Tests
{
    public class GetRouteCommandHandlerTest
    {
    }
}