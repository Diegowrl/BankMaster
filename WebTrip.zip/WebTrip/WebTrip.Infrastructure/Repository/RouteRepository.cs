﻿using System.Data;
using Dapper;
using WebTrip.Domain.Entity;
using WebTrip.Domain.Repositories;
using WebTrip.Infrastructure.Utils;

namespace WebTrip.Infrastructure.Repository
{
    public class RouteRepository : IRouteRepository
    {
        private readonly IDbConnection Connection;

        public RouteRepository(IDbConnection connection)
        {
            Connection = connection ?? throw new ArgumentNullException(nameof(connection));
        }

        public async Task Add(Route item)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@Origem", item.Origem, DbType.String);
            parameters.Add("@Destino", item.Destino, DbType.String);
            parameters.Add("@Valor", item.Valor, DbType.Decimal);
            parameters.Add("@Status", item.Status, DbType.Int16);
            await Connection.ExecuteAsync(SqlQueries.SQL_INSERT_ROUTE, parameters);
        }

        public async Task Update(Route item)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@Id", item.Id, DbType.Int16);
            parameters.Add("@Destino", item.Destino, DbType.String);
            parameters.Add("@Valor", item.Valor, DbType.Decimal);
            await Connection.ExecuteAsync(SqlQueries.SQL_UPDATE_ROUTE, parameters);
        }

        public async Task Delete(Route item)
        {
            DynamicParameters parameters = new DynamicParameters();
            parameters.Add("@Id", item.Id, DbType.Int16);
            parameters.Add("@Status", item.Status , DbType.Int16);
            
            await Connection.ExecuteAsync(SqlQueries.SQL_DELETE_ROUTE, parameters);
        }
    }
}
