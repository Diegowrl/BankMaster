﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebTrip.Infrastructure.Utils
{
    internal static class SqlQueries
    {
        public static string SQL_GET_COUNT_TO_FILTER()
        {
            return @"
				SELECT
				  	COUNT(1)
			FROM Routes
			WHERE Status = 1";
        }

        public static string SQL_GET_ALL()
        {
            return @"
			SELECT  
				   Destino
				  ,Origem
				  ,Valor
				  ,Status
			FROM Routes
			WHERE Status = 1";
        }

        public const string SQL_INSERT_ROUTE = @"
			INSERT INTO Routes (
				  Destino
				 ,Origem
				 ,Valor
				 ,Status)
			VALUES 
			(@Destino, @Origem, @Valor, @Status)
		";

        public const string SQL_UPDATE_ROUTE = @"
			UPDATE Routes
			SET
				Destino = @Destino,
				Valor = @Valor
			WHERE
				Id = @Id
		";

        public const string SQL_DELETE_ROUTE = @"
			UPDATE Routes
			SET
				Status = @Status
			WHERE
				Id = @Id
		";

    }
}
