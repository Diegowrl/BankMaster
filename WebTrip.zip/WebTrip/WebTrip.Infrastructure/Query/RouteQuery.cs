﻿using System.Data;
using Dapper;
using WebTrip.Application.Interfaces;
using WebTrip.Application.Models;
using WebTrip.Domain.Entity;
using WebTrip.Infrastructure.Utils;

namespace WebTrip.Infrastructure.Query
{
    public class RouteQuery : IRouteQuery
    {
        private readonly IDbConnection Connection;

        public RouteQuery(IDbConnection connection)
        {
            Connection = connection ?? throw new ArgumentNullException(nameof(connection));
        }


        public async Task<PagedList<Route>> GetAll()
        {

            var count = await Connection.ExecuteScalarAsync<int>(SqlQueries.SQL_GET_COUNT_TO_FILTER());
            
            return await PagedList<Route>.CreateAsync(async () => { return await Connection.QueryAsync<Route>(SqlQueries.SQL_GET_ALL());}, count, new Pagination { });
        }
    }
}
