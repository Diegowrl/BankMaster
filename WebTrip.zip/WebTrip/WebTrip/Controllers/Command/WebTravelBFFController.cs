﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using WebTrip.Application.Commands.GetRouteBetterCost;
using WebTrip.Application.Interfaces;
using WebTrip.Application.Models;
using WebTrip.Application.Result;

namespace WebTrip.Controllers.Command
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class WebTravelBFFController
    {
        private readonly ILogger<WebTravelController> _logger;
        private readonly IMediator mediator;
        private readonly IRouteQuery _routeQuery;

        public WebTravelBFFController(ILogger<WebTravelController> logger, IMediator mediator, IRouteQuery _routeQuery)
        {
            _logger = logger;
            this.mediator = mediator;
            this._routeQuery = _routeQuery;
        }


        [HttpPost]
        public async Task<Result> PostNew([FromBody] RouteModel item)
        {
            var command = new GetRouteCommand(item);

            var commandResult = await mediator.Send(command);

            return commandResult.Result;
        }
    }
}
