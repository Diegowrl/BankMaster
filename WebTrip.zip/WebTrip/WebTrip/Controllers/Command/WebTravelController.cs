using MediatR;
using Microsoft.AspNetCore.Mvc;
using WebTrip.Application.Commands.CreateRoute;
using WebTrip.Application.Commands.DeleteRoute;
using WebTrip.Application.Commands.GetRouteBetterCost;
using WebTrip.Application.Commands.UpdateRoute;
using WebTrip.Application.Interfaces;
using WebTrip.Application.Models;
using WebTrip.Application.Result;

namespace WebTrip.Controllers.Command
{
    [ApiController]
    [Route("api/v1/[controller]")]
    public class WebTravelController : ControllerBase
    {

        private readonly ILogger<WebTravelController> _logger;
        private readonly IMediator mediator;
        private readonly IRouteQuery _routeQuery;

        public WebTravelController(ILogger<WebTravelController> logger, IMediator mediator, IRouteQuery _routeQuery)
        {
            _logger = logger;
            this.mediator = mediator;
            this._routeQuery = _routeQuery;
        }
        
        [HttpPost]
        public async Task<ResultWrapper> Post([FromBody] RouteModel item)
        {
            var command = new CreateRouteCommand(item);

            var commandResult = await mediator.Send(command);

            return commandResult;
        }
        

        [HttpGet]
        public async Task<IActionResult> Get()
        {
            var result =  await _routeQuery.GetAll();

            if (result.TotalCount == 0)
                return StatusCode(StatusCodes.Status404NotFound, result);

            return StatusCode(StatusCodes.Status200OK, result);
        }

        [HttpPut]
        [Route("{id}")]
        public async Task<ResultWrapper> Put([FromBody] RouteModel item, [FromRoute] int id)
        {
            var command = new UpdateRouteCommand(item, id);

            var commandResult = await mediator.Send(command);

            return ResultWrapper.Ok();
        }

        [HttpDelete]
        [Route("{id}")]
        public async Task<ResultWrapper> Delete(int id)
        {
            var command = new DeleteRouteCommand(id);

            var commandResult = await mediator.Send(command);

            return ResultWrapper.Ok();
        }
    }
}
