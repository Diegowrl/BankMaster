using System.Configuration;
using System.Reflection;
using Cqrs.Hosts;
using MediatR;
using MediatR.NotificationPublishers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.DependencyInjection;
using WebTrip.Application.Behaviors;
using WebTrip.Application.Result;
using WebTrip.CrossCutting;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();

builder.Services.AddSwaggerGen();

builder.Services.AddDependencyResolver();

builder.Services.AddSqlServerConnection("Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\diego\\source\\repos\\WebTrip\\WebTrip.Infrastructure\\database\\Database1.mdf;Integrated Security=True");

var myhandlers = AppDomain.CurrentDomain.Load("WebTrip.Application");
builder.Services.AddMediatR(cfg =>
{
    cfg.RegisterServicesFromAssemblies(myhandlers);
});




var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();



app.MapControllers();

app.Run();
