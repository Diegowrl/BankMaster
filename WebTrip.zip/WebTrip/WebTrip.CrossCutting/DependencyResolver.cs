﻿using System.Data;
using Microsoft.Data.SqlClient;
using Microsoft.Extensions.DependencyInjection;
using WebTrip.Application.Interfaces;
using WebTrip.Domain.Repositories;
using WebTrip.Infrastructure.Query;
using WebTrip.Infrastructure.Repository;

namespace WebTrip.CrossCutting
{
    public static class DependencyResolver
    {
        public static void AddDependencyResolver(this IServiceCollection services)
        {
            services.AddScoped<IRouteQuery, RouteQuery>();
            services.AddScoped<IRouteRepository, RouteRepository>();

        }

        public static void AddSqlServerConnection(this IServiceCollection services, string connectionString)
        {
            services.AddScoped<IDbConnection>(prov => new SqlConnection(connectionString));
        }
    }
}
