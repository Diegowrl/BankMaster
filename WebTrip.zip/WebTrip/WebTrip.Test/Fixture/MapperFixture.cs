﻿//using AutoMapper;

//namespace WebTrip.Test.Fixture
//{
//    public class MapperFixture
//    {
//        public IMapper Mapper { get; }

//        public MapperFixture()
//        {
//            var config = new MapperConfiguration(opts =>
//            {
//            });

//            Mapper = config.CreateMapper();
//        }
//    }
//}
