﻿using WebTrip.Application.Commands.GetRouteBetterCost;
using WebTrip.Application.Models;
using WebTrip.Domain.Entity;

namespace WebTrip.Test.Utils
{
    public static class Util
    {
        public static GetRouteCommand GetValidRouteRequestCommand()
        {
            return new GetRouteCommand(new RouteModel
            {
                Origem = "GRU",
                Destino = "CDG",
                Valor = 0
            });
        }

        public static GetRouteCommand GetValidRouteRequestNotValidCommand()
        {
            return new GetRouteCommand(new RouteModel
            {
                Origem = "CDG",
                Destino = "GRU",
                Valor = 0
            });
        }

        public static List<Route> GetValidRouteRequestList()
        {
            var list = new List<Route>();
            list.Add(new Route("GRU", "BRC", 20));
            list.Add(new Route("BRC", "SCL", 5));
            list.Add(new Route("GRU", "CDG", 75));
            list.Add(new Route("GRU", "SCL", 20));
            list.Add(new Route("GRU", "ORL", 56));
            list.Add(new Route("ORL", "CDG", 5));
            list.Add(new Route("SCL", "ORL", 20));

            return list;
        }
    }
}
