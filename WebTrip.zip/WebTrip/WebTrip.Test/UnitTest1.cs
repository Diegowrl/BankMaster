using FluentAssertions;
using WebTrip.Domain.Entity;
using WebTrip.Application.Interfaces;
using Moq;
using WebTrip.Application.Commands.GetRouteBetterCost;
using WebTrip.Test.Utils;
using Microsoft.AspNetCore.Http;
using WebTrip.Application.Models;


namespace WebTrip.Test
{
    public class UnitTest1
    {

        private readonly Mock<IRouteQuery> RouteQuery;

        public UnitTest1()
        {
            this.RouteQuery = new Mock<IRouteQuery>();
        }

        [Fact]
        public async Task ValidRequestSucess()
        {
            var list = Util.GetValidRouteRequestList();

            Task<PagedList<Route>> paged = PagedList<Route>.CreateAsync(async () => { return list; }, 1, new Pagination { });

            RouteQuery.Setup(p => p.GetAll()).Returns(paged);

            var request = Util.GetValidRouteRequestCommand();

            var handler = new GetRouteCommandHandler(this.RouteQuery.Object);
            //Act
            var result = await handler.Handle(request, CancellationToken.None);

            //Assert
            result.Status.Should().Be(StatusCodes.Status200OK);
        }

        [Fact]
        public async Task ValidRequestHasNoOriginOrDestiny()
        {
            var list = Util.GetValidRouteRequestList();

            Task<PagedList<Route>> paged = PagedList<Route>.CreateAsync(async () => { return list; }, 1, new Pagination { });

            RouteQuery.Setup(p => p.GetAll()).Returns(paged);

            var request = Util.GetValidRouteRequestNotValidCommand();

            var handler = new GetRouteCommandHandler(this.RouteQuery.Object);
            //Act
            var result = await handler.Handle(request, CancellationToken.None);

            //Assert
            result.Status.Should().Be(StatusCodes.Status404NotFound);
        }
    }
}