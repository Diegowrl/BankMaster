﻿using System.Numerics;

namespace WebTrip.Domain.Entity
{
    public class Route
    {

        public Route(string origem, string destino, Decimal valor) {
            
            this.Origem = origem;
            this.Destino = destino;
            this.Valor = valor;
            this.Status = 1;
        }

        public Route(int id)
        {
            this.Id = id;
        }

        protected Route()
        {
        }
        public int Id { get; protected set; }
        public string Origem { get; protected set; }
        public string Destino { get; protected set; }
        public Decimal Valor { get; protected set; }
        public int Status { get; protected set; }

        public void updateToDelete()
        {
            this.Status = 0;
        }
    }
}
