﻿using WebTrip.Domain.Entity;

namespace WebTrip.Domain.Repositories
{
    public interface IRouteRepository
    {
        Task Add(Route item);
        Task Update(Route item);
        Task Delete(Route item);
    }
}
