﻿using System.Data;
using MediatR;
using System.Transactions;
using Microsoft.Extensions.Logging;
using WebTrip.Application.Result;

namespace WebTrip.Application.Behaviors
{
    public class TransactionBehaviour<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse>, IDisposable
    {
        private readonly IDbConnection Connection;
        private readonly ILogger<TransactionBehaviour<TRequest, TResponse>> logger;

        public TransactionBehaviour(IDbConnection connection, ILogger<TransactionBehaviour<TRequest, TResponse>> logger)
        {
            Connection = connection ?? throw new ArgumentNullException(nameof(connection));
            this.logger = logger;
        }

       
        public async Task<TResponse> Handle(TRequest request, CancellationToken cancellationToken, RequestHandlerDelegate<TResponse> next)
        {
            var response = default(TResponse);
            logger.LogInformation("Handling Transaction");

            using (TransactionScope scope = new TransactionScope(TransactionScopeOption.Required,
                GetTransactionOptions(),
                TransactionScopeAsyncFlowOption.Enabled))
            {
                if (Connection.State == ConnectionState.Closed)
                    Connection.Open();

                response = await next();
                if (response is ResultWrapper resultWrapper)
                    scope.Complete();
            }
            logger.LogInformation("Transaction Handled");
            return response;
        }

        private static TransactionOptions GetTransactionOptions() => new TransactionOptions
        {
            IsolationLevel = System.Transactions.IsolationLevel.ReadCommitted,
            Timeout = TransactionManager.MaximumTimeout
        };

        #region Disposable

        private bool disposedValue = false; // To detect redundant calls

        /// <summary>
        /// Calls the protected Dispose method.
        /// </summary>
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        /// <summary>
        /// Function Dispose
        /// </summary>
        /// <param name="disposing">Dispose</param>
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    Connection?.Close();
                    Connection?.Dispose();
                }
                disposedValue = true;
            }
        }

        public Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
        {
            throw new NotImplementedException();
        }
        #endregion
    }
}