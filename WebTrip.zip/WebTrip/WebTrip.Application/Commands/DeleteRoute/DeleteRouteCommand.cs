﻿using MediatR;
using WebTrip.Application.Result;

namespace WebTrip.Application.Commands.DeleteRoute
{
    public class DeleteRouteCommand : IRequest<ResultWrapper>
    {

        public DeleteRouteCommand(int _routeId)
        {
            routeId = _routeId;
        }

        public int routeId { get; }
    }
}