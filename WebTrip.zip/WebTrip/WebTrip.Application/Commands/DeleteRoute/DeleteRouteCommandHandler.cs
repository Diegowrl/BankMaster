﻿using MediatR;
using WebTrip.Application.Result;
using WebTrip.Domain.Entity;
using WebTrip.Domain.Repositories;

namespace WebTrip.Application.Commands.DeleteRoute
{
    public class DeleteRouteCommandHandler : IRequestHandler<DeleteRouteCommand, ResultWrapper>
    {
        private readonly IRouteRepository _routeRepository;

        public DeleteRouteCommandHandler(IRouteRepository routeRepository)
        {
            this._routeRepository = routeRepository;
        }
        public async Task<ResultWrapper> Handle(DeleteRouteCommand request, CancellationToken cancellationToken)
        {

            var item = new Route(request.routeId);

            item.updateToDelete();

            await _routeRepository.Delete(item);

            return ResultWrapper.Created(request);
        }
    }
}