﻿using MediatR;
using WebTrip.Application.Commands.GetRotaBetterCost;
using WebTrip.Application.Interfaces;
using WebTrip.Application.Result;

namespace WebTrip.Application.Commands.GetRouteBetterCost
{
    public class GetRouteCommandHandler : IRequestHandler<GetRouteCommand, ResultWrapper>
    {
        private readonly IRouteQuery _routeQuery;

        public GetRouteCommandHandler(IRouteQuery routeQuery)
        {
            this._routeQuery = routeQuery;
        }
        public async Task<ResultWrapper> Handle(GetRouteCommand request, CancellationToken cancellationToken)
        {
            var result = await _routeQuery.GetAll();
            var resultConcatString = "";

            try
            {
                var resultDij = Dijkstra.EncontrarMelhorRotaV2(result.Data.ToList(), request.route.Origem, request.route.Destino);
                resultConcatString = String.Join(" - ", resultDij.Item1.ToArray()) + $" ao custo de {resultDij.Item2}$";
            }
            catch (Exception)
            {
              return ResultWrapper.NotFound("Não foi encontrado nenhuma rota de Destino ou Origem");
            }

            return ResultWrapper.Ok(String.Join(" - ", resultConcatString) );
        }
    }
}