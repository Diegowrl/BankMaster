﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WebTrip.Application.Commands.GetRouteBetterCost;
using WebTrip.Domain.Entity;

namespace WebTrip.Application.Commands.GetRotaBetterCost
{
    public class Dijkstra
    {
        public static List<string> EncontrarMelhorRota(List<Route> rotas, string origem, string destino)
        {
            var grafo = new Dictionary<string, List<Route>>();
            foreach (var rota in rotas)
            {
                if (!grafo.ContainsKey(rota.Origem))
                {
                    grafo[rota.Origem] = new List<Route>();
                }
                grafo[rota.Origem].Add(rota);
            }

            var distancias = new Dictionary<string, decimal>();
            var anteriores = new Dictionary<string, string>();
            var naoVisitados = new List<string>();

            foreach (var rota in rotas)
            {
                distancias[rota.Origem] = int.MaxValue;
                distancias[rota.Destino] = int.MaxValue;
                naoVisitados.Add(rota.Origem);
                naoVisitados.Add(rota.Destino);
            }

            distancias[origem] = 0;

            while (naoVisitados.Count > 0)
            {
                var atual = naoVisitados.OrderBy(n => distancias[n]).First();
                naoVisitados.Remove(atual);

                if (atual == destino)
                {
                    var caminho = new List<string>();
                    while (anteriores.ContainsKey(atual))
                    {
                        caminho.Insert(0, atual);
                        atual = anteriores[atual];
                    }
                    caminho.Insert(0, origem);
                    return caminho;
                }

                if (distancias[atual] == int.MaxValue)
                {
                    break;
                }

                foreach (var vizinho in grafo[atual])
                {
                    var distanciaAlternativa = distancias[atual] + vizinho.Valor;
                    if (distanciaAlternativa < distancias[vizinho.Destino])
                    {
                        distancias[vizinho.Destino] = distanciaAlternativa;
                        anteriores[vizinho.Destino] = atual;
                    }
                }
            }

            return new List<string> { "Rota não encontrada" };
        }

        public static Tuple<List<string>, int> EncontrarMelhorRotaV2(List<Route> rotas, string origem, string destino)
        {
            var grafo = new Dictionary<string, List<Route>>();
            foreach (var rota in rotas)
            {
                if (!grafo.ContainsKey(rota.Origem))
                {
                    grafo[rota.Origem] = new List<Route>();
                }
                grafo[rota.Origem].Add(rota);
            }

            var distancias = new Dictionary<string, decimal>();
            var anteriores = new Dictionary<string, string>();
            var naoVisitados = new List<string>();

            foreach (var rota in rotas)
            {
                distancias[rota.Origem] = int.MaxValue;
                distancias[rota.Destino] = int.MaxValue;
                naoVisitados.Add(rota.Origem);
                naoVisitados.Add(rota.Destino);
            }

            distancias[origem] = 0;

            while (naoVisitados.Count > 0)
            {
                var atual = naoVisitados.OrderBy(n => distancias[n]).First();
                naoVisitados.Remove(atual);

                if (atual == destino)
                {
                    var caminho = new List<string>();
                    decimal valorTotal = distancias[atual];
                    while (anteriores.ContainsKey(atual))
                    {
                        caminho.Insert(0, atual);
                        atual = anteriores[atual];
                    }
                    caminho.Insert(0, origem);
                    return Tuple.Create(caminho, (int)valorTotal);
                }

                if (distancias[atual] == int.MaxValue)
                {
                    break;
                }

                foreach (var vizinho in grafo[atual])
                {
                    var distanciaAlternativa = distancias[atual] + vizinho.Valor;
                    if (distanciaAlternativa < distancias[vizinho.Destino])
                    {
                        distancias[vizinho.Destino] = distanciaAlternativa;
                        anteriores[vizinho.Destino] = atual;
                    }
                }
            }

            return Tuple.Create(new List<string> { "Rota não encontrada" }, 0);
        }
    }
}