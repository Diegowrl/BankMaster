﻿using MediatR;
using WebTrip.Application.Models;
using WebTrip.Application.Result;

namespace WebTrip.Application.Commands.GetRouteBetterCost
{
    public class GetRouteCommand : IRequest<ResultWrapper>
    {

        public GetRouteCommand(RouteModel _route)
        {
            route = _route;
        }
        
        public RouteModel route { get; }
    }
}