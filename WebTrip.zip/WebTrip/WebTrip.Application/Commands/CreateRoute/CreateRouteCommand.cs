﻿using MediatR;
using WebTrip.Application.Models;
using WebTrip.Application.Result;

namespace WebTrip.Application.Commands.CreateRoute
{
    public class CreateRouteCommand : IRequest<ResultWrapper>
    {
        
		public CreateRouteCommand(RouteModel tripItem)
        {
            Route = tripItem;
        }
        
        public RouteModel Route { get; }
    }
}
