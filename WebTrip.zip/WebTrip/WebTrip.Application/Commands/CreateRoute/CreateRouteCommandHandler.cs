﻿using MediatR;
using WebTrip.Application.Result;
using WebTrip.Domain.Entity;
using WebTrip.Domain.Repositories;

namespace WebTrip.Application.Commands.CreateRoute
{
    public class CreateRouteCommandHandler : IRequestHandler<CreateRouteCommand, ResultWrapper>
    {
        private readonly IRouteRepository _routeRepository;

        public CreateRouteCommandHandler(IRouteRepository routeRepository)
        {
            this._routeRepository = routeRepository;
        }
        public async Task<ResultWrapper> Handle(CreateRouteCommand request, CancellationToken cancellationToken)
        {

            var item = new Route(request.Route.Origem, request.Route.Destino, request.Route.Valor);

            await _routeRepository.Add(item);

            return ResultWrapper.Created(request);
        }
    }
}