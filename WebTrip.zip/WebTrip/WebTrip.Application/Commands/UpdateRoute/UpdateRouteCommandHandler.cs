﻿using MediatR;
using WebTrip.Application.Result;
using WebTrip.Domain.Entity;
using WebTrip.Domain.Repositories;

namespace WebTrip.Application.Commands.UpdateRoute
{
    public class UpdateRouteCommandHandler : IRequestHandler<UpdateRouteCommand, ResultWrapper>
    {
        private readonly IRouteRepository _routeRepository;

        public UpdateRouteCommandHandler(IRouteRepository routeRepository)
        {
            this._routeRepository = routeRepository;
        }
        public async Task<ResultWrapper> Handle(UpdateRouteCommand request, CancellationToken cancellationToken)
        {

            var item = new Route(request.route.Origem, request.route.Destino, request.route.Valor);

            await _routeRepository.Update(item);

            return ResultWrapper.Accepted(request);
        }
    }
}