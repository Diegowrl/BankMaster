﻿using MediatR;
using WebTrip.Application.Models;
using WebTrip.Application.Result;

namespace WebTrip.Application.Commands.UpdateRoute
{
    public class UpdateRouteCommand : IRequest<ResultWrapper>
    {

        public UpdateRouteCommand(RouteModel _route, int _routeId)
        {
            routeId = _routeId;
            route = _route;
        }

        public int routeId { get; }
        public RouteModel route { get; }
    }
}