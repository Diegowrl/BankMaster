﻿using WebTrip.Application.Models;
using WebTrip.Domain.Entity;

namespace WebTrip.Application.Interfaces
{
    public interface IRouteQuery
    {
        Task<PagedList<Route>> GetAll();
    }
}
