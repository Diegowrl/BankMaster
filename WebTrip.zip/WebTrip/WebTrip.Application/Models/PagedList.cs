﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebTrip.Application.Models
{
    public class PagedList<T>
    {
        public PagedList()
        {
        }

        protected PagedList(int count, Pagination pagination)
        {
            TotalCount = count > 0 ? count : 0;
            CurrentPage = pagination.Page;
            PageSize = pagination.PageSize;
            TotalPages = (int)Math.Ceiling(TotalCount / (double)PageSize);
        }

        public IEnumerable<T> Data { get; private set; } = new List<T>();
        public int CurrentPage { get; }
        public int PageSize { get; }
        public int TotalPages { get; }
        public int TotalCount { get; }
        public bool HasPrevious => CurrentPage > 1;
        public bool HasNext => CurrentPage < TotalPages;
        public bool IsFirstPage => CurrentPage == 1;
        public bool IsLastPage => !HasNext;

        public async static Task<PagedList<T>> CreateAsync(Func<Task<IEnumerable<T>>> fillItems, int count, Pagination pagination)
        {
            var result = new PagedList<T>(count, pagination);
            if (count == 0)
                return result;
            if (result.CurrentPage > result.TotalPages)
                return result;
            result.Data = await fillItems();
            return result;
        }
    }
}
