﻿using System.ComponentModel.DataAnnotations;

namespace WebTrip.Application.Models
{
    public class RouteModel
    { 
        
        [Required(ErrorMessage = "{0} não pode ser vazio.", AllowEmptyStrings = false)]
        public string Origem { get; set; }


		[Required(ErrorMessage = "{0} não pode ser vazio.", AllowEmptyStrings = false)]
        public string Destino { get; set; }


        public Decimal Valor { get; set; }
    }
}
