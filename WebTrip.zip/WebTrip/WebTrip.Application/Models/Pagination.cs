﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebTrip.Application.Models
{
    public class Pagination
    {
        private const int maxPageSize = 100;
        private int _pageSize = 10;
        private int page = 1;

        public int Page { get => page; set => page = value < 1 ? 1 : value; }

        public int PageSize { get => _pageSize; set => _pageSize = IsBetween(value, 1, maxPageSize) ? value : _pageSize; }


        public static bool IsBetween(int value, int min, int max)
        {
            return value >= min && value <= max;
        }
    }
}
