﻿using System;
using Flunt.Notifications;
using MediatR;
using Microsoft.AspNetCore.Http;

namespace WebTrip.Application.Result
{
    public class ResultWrapper
    {
        public int Status { get; protected set; }
        public Result Result { get; set; }

        
        public static ResultWrapper CreateResponse(int status)
        {
            return new ResultWrapper { Status = status };
        }

        public static ResultWrapper NotFound<T>(T obj)
        {
            var response = CreateResponse(StatusCodes.Status404NotFound);
            response.Result = new Result<T>(obj);
            response.Result.Status = StatusCodes.Status404NotFound;
            return response;
        }

        public static ResultWrapper Ok()
        {
            return CreateResponse(StatusCodes.Status200OK); ;
        }

        public static ResultWrapper Ok<T>(T obj)
        {
            var response = CreateResponse(StatusCodes.Status200OK);
            response.Result = new Result<T>(obj);
            response.Result.Status = StatusCodes.Status200OK;
            return response;
        }

        public static ResultWrapper Error(string property, string message)
        {
            var response = CreateResponse(StatusCodes.Status400BadRequest);
            response.Result = new Result();
            response.Result.Status = StatusCodes.Status400BadRequest;
            return response;
        }

        public static ResultWrapper Created<T>(T obj)
        {
            var response = CreateResponse(StatusCodes.Status201Created);
            response.Result = new Result<T>(obj);
            response.Result.Status = StatusCodes.Status201Created;
            return response;
        }

        public static ResultWrapper Accepted<T>(T obj)
        {
            var response = CreateResponse(StatusCodes.Status202Accepted);
            response.Result = new Result<T>(obj);
            response.Result.Status = StatusCodes.Status202Accepted;
            return response;
        }
    }


    public class Result
    {
        public int Status { get; set; }
    }

    public class Result<T> : Result
    {
        public T Data { get; }
        public Result(T data) => Data = data;
    }
}
