﻿using Flunt.Notifications;

namespace WebTrip.Application.Result
{
    public class NotificationResult : Notifiable
    {
    }
}
